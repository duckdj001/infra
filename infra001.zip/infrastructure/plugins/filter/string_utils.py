# Try to find external modules
try:
    from slugify import slugify
    HAS_SLUGIFY = True
except ImportError:
    HAS_SLUGIFY = False

def _slugify(string, entities=True, decimal=True, hexadecimal=True, max_length=0, word_boundary=False,
             separator='-', save_order=False, stopwords=()):
    if not HAS_SLUGIFY:
        module.fail_json(msg='slugify required for this module')
    if string is None:
        return ''
    return slugify(string, entities, decimal, hexadecimal, max_length, word_boundary,
                   separator, save_order, stopwords)

class FilterModule(object):

    def filters(self):
        return {
            'slugify': _slugify
        }
