<a name="1.5.0"></a>
## 1.5.0 (2021-07-08)


#### Features

*   more parameters for recovery.conf ([15b19332](15b19332))
*   add postgresql collection ([b63d694e](b63d694e))



<a name="1.4.2"></a>
## 1.4.2 (2021-04-17)


#### Bug Fixes

*   quotes in recovery.conf ([752e4601](752e4601))



<a name="1.4.1"></a>
## 1.4.1 (2021-04-17)


#### Bug Fixes

*   do not force become method ([00662eeb](00662eeb))



<a name="1.4.0"></a>
## 1.4.0 (2021-04-17)


#### Bug Fixes

*   tests? ([659e72d6](659e72d6))

#### Features

*   add more parameters to recovery.conf ([89b1e6ba](89b1e6ba))
*   Add restore conf and update molecule testing ([5436b6ef](5436b6ef))



<a name="1.3.0"></a>
## 1.3.0 (2021-04-08)


#### Features

*   add support for groups ([d3f28a6b](d3f28a6b))



<a name="1.2.2"></a>
## 1.2.2 (2021-03-01)


#### Features

*   add collections ([002de5e5](002de5e5))



<a name="1.2.1"></a>
## 1.2.1 (2020-07-21)


#### Features

*   open port for postgresql ([2571b029](2571b029))



<a name="1.1.0"></a>
## 1.1.0 (2020-04-07)


#### Bug Fixes

*   Enable service and initilize db ([8049c01a](8049c01a))



<a name="1.0.0"></a>
## 1.0.0 (2020-03-02)




<a name="0.0.1"></a>
## 0.0.1 (2019-11-20)


#### Bug Fixes

*   Change default version, fix some errors in README ([992406fa](992406fa))



<a name="0.1.1"></a>
## 0.1.1 (2019-03-07)


#### Features

*   add molecule requirements feat: add Makefile ([b4f5ac73](b4f5ac73))



