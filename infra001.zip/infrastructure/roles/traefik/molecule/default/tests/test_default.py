import os

import testinfra.utils.ansible_runner

testinfra_hosts = testinfra.utils.ansible_runner.AnsibleRunner(
    os.environ['MOLECULE_INVENTORY_FILE']).get_hosts('all')

traefik_version = '2.2.1'


def test_traefik_binary(host):
    f = host.file(f'/opt/traefik/traefik_{traefik_version}')

    assert f.exists
    assert f.user == 'root'
    assert f.group == 'root'
    assert f.mode == 0o755


def test_traefik_service(host):
    s = host.service('traefik')

    assert s.is_running
    assert s.is_enabled


def test_traefik_process(host):
    p = host.process.get(comm=f'traefik_{traefik_version}')
    assert p.user == 'traefik'


def test_acme_storage(host):
    acme_storage_dir = host.file('/opt/traefik/acme')

    assert acme_storage_dir.user == 'traefik'
    assert acme_storage_dir.mode == 0o700

    acme_storage = host.file('/opt/traefik/acme/leresolver.json')

    assert acme_storage.user == 'traefik'
    assert acme_storage.mode == 0o600


def test_firewalld(host):
    out = host.check_output('firewall-cmd --list-ports')
    assert out == '80/tcp 443/tcp'

    out = host.check_output('firewall-cmd --list-ports --permanent')
    assert out == '80/tcp 443/tcp'


def test_certificates(host):
    cert = host.file('/etc/traefik/ssl/traefik_test.crt')
    key = host.file('/etc/traefik/ssl/traefik_test.key')

    assert cert.user == 'traefik'
    assert key.user == 'traefik'

    assert cert.mode == 0o644
    assert key.mode == 0o600


def test_certificates_config(host):
    conf = host.file('/etc/traefik/dynamic/certificates.toml')

    assert 'certFile = "/etc/traefik/ssl/traefik_test.crt"' \
        in conf.content_string
