# traefik

Настраивает traefik

Общая информация: https://docs.traefik.io/

## Пример использования

Минимальный рекомендуемый конфиг для прода:

```yaml
traefik_manage_firewalld: true
traefik_leresolver_caserver: "https://acme-v02.api.letsencrypt.org/directory"
traefik_providers:
  - docker
```

- traefik_version - версия traefik. Все прошлые версии хранятся в скаченном виде в /opt/download и в распакованном виде в /opt/traefik/traefik_{{ traefik_version }}
- traefik_manage_firewalld - открывать ли порты для entrypoint в firewalld
- traefik_entrypoints - список энтрипоинтов.
    Возможные параметры:
    - name -- название
    - address -- адрес, который будет слушать traefik
    - tls -- требовать tls на порту
    - certResolver -- если указано traefik будет использовать этот резолвер для
      получения сертификатов. `leresolver` для использования Lets Encrypt

### Провайдеры (traefik_providers)

Поддерживаются следующие провайдеры динамической конфигурации:
- `file` - файлы из папки `traefik_provider_file_directory` (`/etc/traefik/dynamic` по умолчанию)
  работает всегда, включать не нужно.
- `docker` - связь по лейблам из docker

###  Конфигурация Lets Encrypt

- traefik_leresolver_caserver -- сервер для выпуска сертификатов. По умолчанию
  используется staging LE. Для продуктивного установить в
  `https://acme-v02.api.letsencrypt.org/directory`
- traefik_leresolver_entrypoint -- entryPoint для HTTP-01 проверки
- traefik_leresolver_email -- email для регистрации в LE

### Локальные сертификаты

- traefik_certificates - массив объектов с полями
  - cert - имя локального файла с сертификатом
  - key - имя локального файла с ключем


## Разработка

При начале разработки новой роли требуется настроить виртуальное окружение python:

```shell
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

Для версионирования используется система семантического версионирования (https://semver.org/lang/ru/)

Для использования автоматической генерации CHANGELOG.md требуется установить пакет clog

Для повышения патч-версии необходимо использовать команду
```shell
make patch
```

Для повышения минорной версии необходимо использовать команду
```shell
make minor
```

Для повышения мажорной версии необходимо использовать команду
```shell
make major
```

При выполнение данных команд в репозитории не должно быть никаких незафиксированных изменений.

При выполнение команды `make` будет также создан и сформирован файл CHANGELOG.md, формирование файла будет основано на
сделанных коммитах в репозитории.

Все коммиты должны следовать системе `conventional commit` https://www.conventionalcommits.org/en/v1.0.0/

Перед выпуском мажорной версии роли maintainer проекта проверят наличие заполненого описание роли в файле README.md

Повышение мажорной версии до 1 выполняется только в случае полной готовности роли по функционалу, успешного прохождения пайплайна в gitlab,
дальнейшее увеличение мажорной версии происходит только в случае обратно несовместимых изменений

Для подключения роли в плейбук применяемый к продуктивному окружению используется только стабильная версия роли.


## Links

[Семантическое версионирование](https://semver.org/lang/ru/)

[Conventional commit](https://www.conventionalcommits.org/en/v1.0.0/)

[Общая директория с ролями ansible](https://git.alp.ru/ansible/roles)
