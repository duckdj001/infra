<a name="1.2.2"></a>
## 1.2.2 (2020-07-08)


#### Bug Fixes

*   use real value for certResolver ([de0c15bb](de0c15bb))



<a name="1.2.1"></a>
## 1.2.1 (2020-07-06)


#### Bug Fixes

*   file provider ([7b87eded](7b87eded))



<a name="1.2.0"></a>
## 1.2.0 (2020-07-06)


#### Features

*   make file provider work always ([5195209d](5195209d))
*   add traefik dashboard ([34bb3ffb](34bb3ffb))



<a name="1.1.4"></a>
## 1.1.4 (2020-07-06)


#### Features

*   add https redirect middleware ([85710b93](85710b93))



<a name="1.1.3"></a>
## 1.1.3 (2020-07-06)


#### Bug Fixes

*   open ports immediate ([ff0c41d0](ff0c41d0))
*   prepare playbook ([9574e90f](9574e90f))



<a name="1.1.2"></a>
## 1.1.2 (2020-07-06)


#### Bug Fixes

*   firewalld template ([5f507fd3](5f507fd3))



<a name="1.1.1"></a>
## 1.1.1 (2020-07-06)


#### Bug Fixes

*   disable exposedByDefault for docker ([fc4c5116](fc4c5116))



<a name="1.1.0"></a>
## 1.1.0 (2020-07-06)


#### Bug Fixes

*   add LE email ([d7d3ea38](d7d3ea38))

#### Features

*   manage firewalld ([c9fd658c](c9fd658c))



<a name="1.0.0"></a>
## 1.0.0 (2020-07-06)


#### Features

*   first role version ([a714799b](a714799b))

#### Bug Fixes

*   ci ([759c4025](759c4025))
*   make tests pass ([51694684](51694684))
*   make molecule work ([214bae9e](214bae9e))



<a name="0.0.1"></a>
## 0.0.1 (2019-11-20)


#### Bug Fixes

*   Change default version, fix some errors in README ([992406fa](992406fa))



<a name="0.1.1"></a>
## 0.1.1 (2019-03-07)


#### Features

*   add molecule requirements feat: add Makefile ([b4f5ac73](b4f5ac73))



