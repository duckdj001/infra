# metro-app-skel

Скелет для php приложений.

## Cобственные переменные

Переменная | Значение по умолчанию | Описание
--- | --- | ---
`metro_skel_include_db` | false | включить установку БД (роль percona-server)
`metro_skel_app_user` | app | пользователь для работы php-fpm
`metro_skel_app_group` | app | группа для работы php-fpm
`metro_skel_nginx_server_name` | _ | имя сервера в nginx
`metro_skel_nginx_server_root` | /opt/app/app | web каталог приложения
`metro_skel_nginx_index` | index.php index.html index.htm | параметр index в блоке server nginx
`metro_skel_php_repo` | remi-php74 | репозиторий php
`metro_skel_nginx_extra` | | параметры конфигурации nginx
`metro_skel_db_name` | | имя создаваемой БД
`metro_skel_db_user` | | пользователь создаваемой БД
`metro_skel_db_user_password` | | пароль пользователя создаваемой БД
`metro_skel_db_user_host` | localhost | хост пользователя БД (необходимо для GRANT)

## Дополнительные переменные

Переменные ролей:

* geerlingguy.nginx
* geerlingguy.repo-remi
* geerlingguy.php
* percona-server

## Пример использования

```
---
- name: Skel
  hosts: app
  vars:
    metro_skel_php_repo: remi-php70
    metro_skel_include_db: true
    mysql_root_password: "Hellooooo21!"
    metro_skel_db_name: test
    metro_skel_db_user: test
    metro_skel_db_user_password: "Hellooooo21!"
    php_packages:
      - php-opcache
      - php-fpm
      - php-ffi
      - php-cli
      - php-gd
      - php-mbstring
      - php-mysqlnd
      - php-pdo
  roles:
    - role: metro-app-skel

```

## Разработка

При начале разработки новой роли требуется настроить виртуальное окружение python:

```shell
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

Для возможности локального тестирования роли рекомендуется настроить виртуальное окружение, установив в него следующие пакеты:
```shell
pip install -r requirements_molecule.txt
```

Для версионирования используется система семантического версионирования (https://semver.org/lang/ru/)

Для использования автоматической генерации CHANGELOG.md требуется установить пакет clog

Для повышения патч-версии необходимо использовать команду
```shell
make patch
```

Для повышения минорной версии необходимо использовать команду
```shell
make minor
```

Для повышения мажорной версии необходимо использовать команду
```shell
make major
```

При выполнение данных команд в репозитории не должно быть никаких незафиксированных изменений.

При выполнение команды `make` будет также создан и сформирован файл CHANGELOG.md, формирование файла будет основано на
сделанных коммитах в репозитории.

Все коммиты должны следовать системе `conventional commit` https://www.conventionalcommits.org/en/v1.0.0/

Перед выпуском мажорной версии роли maintainer проекта проверят наличие заполненого описание роли в файле README.md

Повышение мажорной версии до 1 выполняется только в случае полной готовности роли по функционалу, успешного прохождения пайплайна в gitlab,
дальнейшее увеличение мажорной версии происходит только в случае обратно несовместимых изменений

Для подключения роли в плейбук применяемый к продуктивному окружению используется только стабильная версия роли.


## Links
[Семантическое версионирование](https://semver.org/lang/ru/)
[Conventional commit](https://www.conventionalcommits.org/en/v1.0.0/)
[Общая директория с ролями ansible](https://git.alp.ru/ansible/roles)