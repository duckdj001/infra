<a name="1.3.0"></a>
## 1.3.0 (2021-07-28)


#### Bug Fixes

*   test option ([df1e2f42](df1e2f42))
*   quotes ([d59c5dca](d59c5dca))

#### Features

*   add backup option ([81dd6639](81dd6639))



<a name="1.2.2"></a>
## 1.2.2 (2021-05-31)


#### Bug Fixes

*   restic prune dependepcy cycle ([7a0af8d2](7a0af8d2))



<a name="1.1.0"></a>
## 1.1.0 (2021-02-11)


#### Features

*   add snapshot validation ([afb126f1](afb126f1))
*   repository cleanup ([1b0925f3](1b0925f3))

#### Bug Fixes

*   linting ([01403148](01403148))
*   deduging ([eeba3979](eeba3979))



<a name="1.0.0"></a>
## 1.0.0 (2021-02-10)


#### Features

*   update Readme.md ([3a3a3f0c](3a3a3f0c))
*   configure role ([7aa23af1](7aa23af1))
*   add readme ([672d1b76](672d1b76))

#### Bug Fixes

*   change the metgod of getting varables ([c42f6a35](c42f6a35))
*   update tests ([a1d26952](a1d26952))
*   rename variables clear Changelog ([e4bf9fa1](e4bf9fa1))



