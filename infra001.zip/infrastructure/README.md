# Infrastructure

## 🚀 Быстрый старт

### 1. Проверьте версию Python

```bash
python3 --version
```

### 2. Проверьте Python на управляемых машинах

```bash
# Проверить Python на удаленных серверах
ansible all -i inventory/dev/10-local.yaml -m raw -a "python3 --version" --vault-id @vault_id.sh -u ваш_юзер
```

### 3. Установка

**📖 [Документация по venv](https://asap.atlassian.net/wiki/spaces/ASAPTECH/pages/229998593/venv)**

```bash
# Создайте виртуальное окружение
python3 -m venv ~/venv/metro

# Активируйте его
source ~/venv/metro/bin/activate

# Выберите файл зависимостей в зависимости от вашего Python:
# Для Python 3.8-3.11 на control node:
pip install -r requirements.txt

# Для Python 3.12+ на control node:
pip install -r requirements-ansible-8.7.txt

# Для новых Ubuntu хостов:
pip install -r ubuntu-requirements.txt

# Установите роли Ansible
ansible-galaxy install -r requirements.yml
```

### 4. Выбор файла зависимостей

| **Файл**                       | **Ansible** | **Control Node Python** | **Описание**                                           |
| ------------------------------ | ----------- | ----------------------- | ------------------------------------------------------ |
| `requirements.txt`             | **2.10**    | **Python 3.8-3.11**     | Оригинальный файл, работает со старыми версиями Python |
| `requirements-ansible-8.7.txt` | **8.7**     | **Python 3.12+**        | Современная версия, совместим с новым Python           |
| `ubuntu-requirements.txt`      | **10.7**    | **Python 3.8+**         | Для новых хостов на OS Ubuntu                          |

```bash
# В зависимости от вашего Python на control node:
pip install -r requirements.txt                # Python 3.8-3.11
pip install -r requirements-ansible-8.7.txt   # Python 3.12+
pip install -r ubuntu-requirements.txt        # Ubuntu хосты
```

---

## 📋 Подробная информация

## ⚠️ ВАЖНО: Выбор в зависимости от версии Python

### 🎯 **Правила выбора файла:**

1. **Python 3.8-3.11 на control node**: используйте `requirements.txt` (Ansible 2.10)
2. **Python 3.12+ на control node**: используйте `requirements-ansible-8.7.txt` (Ansible 8.7)
3. **Новые Ubuntu хосты**: используйте `ubuntu-requirements.txt` (Ansible 10.7)

### 🚨 **Проблемы совместимости:**

1. **Ansible 2.10 + Python 3.12+**: `ModuleNotFoundError: ansible.module_utils.six.moves`
2. **Ansible 11.7+ + Python 3.6 на managed nodes**: `SyntaxError: future feature annotations is not defined`

### ✅ РЕШЕНИЕ:

**Выберите версию Ansible в зависимости от вашего окружения:**

```bash
# 1. Проверьте Python на control node
python3 --version

# 2. Проверьте Python на managed nodes
ansible all -i inventory/dev/10-local.yaml -m raw -a "python3 --version" --vault-id @vault_id.sh -u ваш_юзер

# 3. Выберите подходящий файл:
# Python 3.8-3.11 → requirements.txt
# Python 3.12+    → requirements-ansible-8.7.txt
```

### Таблица совместимости:

| **Control Node**    | **Managed Nodes** | **Ansible** | **Файл**                       | **Статус**          |
| ------------------- | ----------------- | ----------- | ------------------------------ | ------------------- |
| **Python 3.8-3.11** | **Python 3.6+**   | **2.10**    | `requirements.txt`             | ✅ **РАБОТАЕТ**     |
| **Python 3.12+**    | **Python 3.6+**   | **8.7**     | `requirements-ansible-8.7.txt` | ✅ **РАБОТАЕТ**     |
| **Python 3.8+**     | **Python 3.8+**   | **10.7**    | `ubuntu-requirements.txt`      | ✅ **Ubuntu хосты** |

### 🐧 **Ubuntu Requirements**

Файл `ubuntu-requirements.txt` используется для **новых созданных хостов** которые развернуты на **OS Ubuntu**:

- ✅ Ansible 10.7 - современная версия для Ubuntu
- ✅ Обновленные версии пакетов
- ✅ Совместим с новыми Ubuntu системами

```bash
# Для работы с новыми Ubuntu хостами
pip install -r ubuntu-requirements.txt
```

### Дополнительные системные зависимости (при необходимости)

Если возникают ошибки компиляции:

```bash
sudo apt install python3-venv python3-dev libyaml-dev
```

### Ежедневное использование

```bash
# Активируйте окружение
source ~/venv/metro/bin/activate

# Работайте с ansible
ansible --version
ansible-playbook playbook_name.yaml

# Деактивируйте по завершении
deactivate
```

### Миграция и обновления

**Выбор правильной версии:**

```bash
source ~/venv/metro/bin/activate

# 1. Проверьте версию Python на control node
python3 --version

# 2. Проверьте Python на managed nodes
ansible all -i inventory/dev/10-local.yaml -m raw -a "python3 --version" --vault-id @vault_id.sh -u ваш_юзер

# 3. Установите подходящую версию:
pip uninstall ansible ansible-lint -y

# Для Python 3.8-3.11:
pip install -r requirements.txt

# Для Python 3.12+:
pip install -r requirements-ansible-8.7.txt
```

---

## ✅ **Гибкий выбор в зависимости от окружения!** ✨

**Каждая версия Ansible имеет свои преимущества**

### 💡 **Структура файлов:**

- `requirements.txt` - **Ansible 2.10** (для Python 3.8-3.11)
- `requirements-ansible-8.7.txt` - **Ansible 8.7** (для Python 3.12+)
- `ubuntu-requirements.txt` - **Ansible 10.7** (для Ubuntu хостов)

### Проверка работоспособности:

```bash
source ~/venv/metro/bin/activate
ansible --version  # Версия зависит от выбранного файла
```

---

## ❓ FAQ

**Q: У меня ошибка `externally-managed-environment`**
A: Используйте виртуальное окружение: `python3 -m venv ~/venv/metro && source ~/venv/metro/bin/activate`

**Q: `ModuleNotFoundError: ansible.module_utils.six.moves`**
A: У вас Python 3.12+ с Ansible 2.10. Используйте: `pip install -r requirements-ansible-8.7.txt`

**Q: `SyntaxError: future feature annotations is not defined`**  
A: У вас Ansible 11.7+ с Python 3.6 на managed nodes. Используйте Ansible 8.7 или ниже.

**Q: Какую версию Ansible я использую?**
A: `ansible --version` (в активированном виртуальном окружении)

**Q: Какой файл requirements использовать?**
A: Зависит от версии Python на control node:

- **Python 3.8-3.11**: `requirements.txt` (Ansible 2.10)
- **Python 3.12+**: `requirements-ansible-8.7.txt` (Ansible 8.7)
- **Ubuntu хосты**: `ubuntu-requirements.txt` (Ansible 10.7)

**Q: В чем разница между файлами?**
A:

- `requirements.txt` - Ansible 2.10, совместим с Python 3.8-3.11
- `requirements-ansible-8.7.txt` - Ansible 8.7, совместим с Python 3.12+
- `ubuntu-requirements.txt` - Ansible 10.7, для новых Ubuntu хостов

**Q: Когда использовать ubuntu-requirements.txt?**
A: При работе с **новыми созданными хостами** которые развернуты на **OS Ubuntu** и имеют современные версии Python.

**Q: Какая версия Ansible лучше?**
A: Все версии хороши для своих сценариев. Выбирайте исходя из версии Python и требований проекта.
