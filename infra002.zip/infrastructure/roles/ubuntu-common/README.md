# Ubuntu Common Role

Роль для полной настройки Ubuntu серверов - установка пакетов, настройка времени, системных параметров и инициализация.

## Описание

Эта роль выполняет полную инициализацию Ubuntu серверов:
- Обновление hostname
- Настройка timezone
- Обновление APT кэша и пакетов
- Установка базовых утилит
- Настройка chrony для синхронизации времени
- Настройка persistent хранения journald логов
- Настройка системных лимитов (ulimit)
- Настройка системных параметров ядра (sysctl)
- Отключение DNS управления в NetworkManager
- Конфигурация resolv.conf
- Отключение SWAP (автоматически для определенных групп)
- Регенерация SSH host ключей
- Управление перезагрузкой системы
- Настройка APT репозиториев для использования прокси Nexus
- Полное отключение IPv6

## Требования

- Ubuntu 22.04 (Jammy) или Ubuntu 24.04 (Noble)
- Права sudo на целевых хостах
- Ansible 2.9+

## Переменные

### Базовые настройки
| Переменная | Значение по умолчанию | Описание |
|------------|----------------------|----------|
| `ubuntu_common_packages` | [список пакетов] | Базовые пакеты для установки |
| `ubuntu_extra_packages` | [] | Дополнительные пакеты |
| `ubuntu_timezone` | UTC | Часовой пояс |
| `ubuntu_update_hostname` | true | Обновлять hostname |
| `ubuntu_update_packages` | true | Обновлять APT кэш |
| `ubuntu_upgrade_packages` | false | Обновлять все пакеты |

### Chrony настройки
| Переменная | Значение по умолчанию | Описание |
|------------|----------------------|----------|
| `ubuntu_manage_chrony` | true | Настраивать chrony |
| `ubuntu_chrony_servers` | [Ubuntu NTP pool] | NTP серверы |
| `ubuntu_chrony_pool` | [] | Список NTP pool серверов |
| `ubuntu_chrony_source_servers` | [] | Список конкретных NTP серверов |
| `ubuntu_chrony_server` | [] | Список серверов, которые будут выступать в качестве NTP сервера для клиентов |
| `ubuntu_chrony_allow_networks` | [] | Список сетей, которым разрешено запрашивать этот NTP сервер |

### Journald настройки
| Переменная | Значение по умолчанию | Описание |
|------------|----------------------|----------|
| `ubuntu_configure_journald` | true | Настраивать persistent хранение journald |
| `ubuntu_journald_max_size` | "1G" | Максимальный размер журналов |
| `ubuntu_journald_retention` | "1month" | Время хранения журналов |

### Системные настройки (из ubuntu-init)
| Переменная | Значение по умолчанию | Описание |
|------------|----------------------|----------|
| `ubuntu_disable_swap` | auto | Отключить SWAP для групп: mp_elastic, apm, events_elastic, k8s_* |
| `ubuntu_regenerate_ssh_keys` | true | Регенерировать SSH host ключи |
| `ubuntu_disable_nm_dns` | true | Отключить DNS в NetworkManager |
| `ubuntu_configure_limits` | true | Настроить системные лимиты |
| `ubuntu_user_limit` | "65535" | Лимит файлов для пользователей |
| `ubuntu_root_limit` | "65535" | Лимит файлов для root |
| `ubuntu_configure_resolv` | true | Настроить resolv.conf |
| `ubuntu_nameservers` | [8.8.8.8, 8.8.4.4] | DNS серверы |
| `ubuntu_resolv_search` | [] | Список доменов для поиска |
| `ubuntu_resolv_options` | [] | Список опций для resolv.conf |
| `ubuntu_ssh_key_types` | [rsa, ecdsa, ed25519] | Типы SSH ключей |

### Sysctl настройки
| Переменная | Значение по умолчанию | Описание |
|------------|----------------------|----------|
| `ubuntu_sysctl_params` | [список параметров] | Основные sysctl параметры |
| `ubuntu_sysctl_extra` | [] | Дополнительные параметры |
| `ubuntu_sysctl_file` | /etc/sysctl.d/99-ubuntu-tuning.conf | Файл конфигурации |
| `ubuntu_sysctl_reload` | true | Применять параметры немедленно |

### Перезагрузка
| Переменная | Значение по умолчанию | Описание |
|------------|----------------------|----------|
| `ubuntu_reboot_after_update` | false | Перезагружать после обновлений |
| `ubuntu_reboot_timeout` | 300 | Таймаут перезагрузки |

### APT репозитории
| Переменная | Значение по умолчанию | Описание |
|------------|----------------------|----------|
| `ubuntu_apt_nexus_repo_enabled` | false | Включить настройку Nexus APT репозитория |
| `ubuntu_apt_nexus_repo_url` | "https://nexus.metro-cc.ru/repository/apt_ubuntu_noble/" | URL Nexus APT репозитория |
| `ubuntu_apt_distro_codename` | "noble" | Кодовое имя дистрибутива Ubuntu |
| `ubuntu_apt_components` | ['main', 'restricted', 'universe', 'multiverse'] | Компоненты репозитория |

### IPv6 настройки
| Переменная | Значение по умолчанию | Описание |
|------------|----------------------|----------|
| `ubuntu_disable_ipv6` | false | Полностью отключить IPv6 |

## Устанавливаемые пакеты

По умолчанию устанавливаются:
- vim, htop, sysstat, tmux
- curl, wget, netcat, tree, unzip
- software-properties-common
- apt-transport-https
- ca-certificates, gnupg, lsb-release

## Автоматическое отключение SWAP

SWAP автоматически отключается для хостов, входящих в следующие группы:
- `mp_elastic` - Elasticsearch для маркетплейса
- `apm` - APM серверы
- `events_elastic` - Elasticsearch для событий
- `k8s_master` - Kubernetes мастер узлы
- `k8s_ingress` - Kubernetes ingress узлы
- `k8s_node` - Kubernetes рабочие узлы

Для других групп SWAP остается включенным.

## Persistent хранение journald

Роль автоматически настраивает persistent хранение для systemd-journald:
- Создает директорию `/var/log/journal`
- Настраивает `Storage=persistent` в `/etc/systemd/journald.conf`
- Устанавливает лимиты размера и времени хранения
- Логи сохраняются после перезагрузки системы

## Использование

### Базовое использование
```yaml
---
- name: Configure Ubuntu servers
  hosts: ubuntu_servers
  become: true
  roles:
    - ubuntu-common
```

### С настройкой journald
```yaml
---
- name: Configure Ubuntu with custom journald
  hosts: ubuntu_servers
  become: true
  vars:
    ubuntu_journald_max_size: "2G"
    ubuntu_journald_retention: "3months"
  roles:
    - ubuntu-common
```

### Принудительное отключение SWAP
```yaml
---
- name: Configure Ubuntu with disabled SWAP
  hosts: ubuntu_servers
  become: true
  vars:
    ubuntu_disable_swap: true
  roles:
    - ubuntu-common
```

### С дополнительными пакетами
```yaml
---
- name: Configure Ubuntu with extras
  hosts: ubuntu_servers
  become: true
  vars:
    ubuntu_extra_packages:
      - docker.io
      - python3-pip
    ubuntu_timezone: Europe/Moscow
    ubuntu_disable_nm_dns: false
  roles:
    - ubuntu-common
```

### Селективное выполнение
```bash
# Только установка пакетов
ansible-playbook playbook.yml --tags packages

# Только настройка времени
ansible-playbook playbook.yml --tags chrony

# Только системные лимиты
ansible-playbook playbook.yml --tags limits

# Только DNS настройки
ansible-playbook playbook.yml --tags dns

# Только SSH ключи
ansible-playbook playbook.yml --tags ssh

# Только Sysctl настройки
ansible-playbook playbook.yml --tags tuning

# Только APT репозитории
ansible-playbook playbook.yml --tags apt-repo

# Только IPv6 настройки
ansible-playbook playbook.yml --tags ipv6
```

## Теги

- `packages` - установка пакетов
- `chrony` - настройка времени
- `journald` - настройка journald
- `limits` - системные лимиты
- `dns` - настройка DNS
- `ssh` - SSH ключи
- `tuning` - системная оптимизация
- `apt-repo` - настройка APT репозиториев
- `ipv6` - настройка IPv6
- `ubuntu-common` - все задачи роли

## Выполняемые задачи

### Journald persistent хранение
- Создает директорию `/var/log/journal` с правильными правами
- Настраивает `Storage=persistent` в конфигурации
- Устанавливает лимиты размера (`SystemMaxUse`)
- Настраивает время хранения (`MaxRetentionSec`)
- Перезапускает systemd-journald для применения настроек

### Системные лимиты
Настраивает `/etc/security/limits.conf`:
- `* soft nofile 65535`
- `* hard nofile 65535`
- `root soft nofile 65535`
- `root hard nofile 65535`

### NetworkManager DNS
- Отключает DNS управление в NetworkManager
- Останавливает systemd-resolved
- Предотвращает конфликты DNS

### DNS resolver
- Создает статический `/etc/resolv.conf`
- Делает файл неизменяемым (chattr +i)
- Использует указанные DNS серверы, домены для поиска (`search`) и опции (`options`).

### SWAP отключение (автоматическое)
- Проверяет принадлежность к группам
- Выполняет `swapoff -a` для нужных групп
- Удаляет записи из `/etc/fstab`
- Удаляет swap файлы

### SSH host ключи
- Удаляет все существующие ключи
- Генерирует новые ключи (RSA, ECDSA, ED25519)
- Устанавливает правильные права доступа

### Sysctl параметры
- Создает файл `/etc/sysctl.d/99-ubuntu-tuning.conf` с настроенными параметрами.
- Применяет параметры немедленно через модуль `sysctl`.
- Обеспечивает постоянство параметров через конфигурационный файл.

### APT репозитории
- Создает файл `/etc/apt/sources.list.d/nexus.list` с указанным Nexus репозиторием.
- Удаляет стандартный `/etc/apt/sources.list` для предотвращения конфликтов.
- Обновляет кэш APT после изменения репозиториев.

### Отключение IPv6
- Отключает IPv6 через параметры ядра (sysctl).
- Добавляет параметр `ipv6.disable=1` в GRUB для постоянного отключения при загрузке.


## Файлы

- `tasks/main.yaml` - основные задачи
- `tasks/chrony.yaml` - настройка chrony
- `tasks/journald.yaml` - настройка journald
- `tasks/reboot.yaml` - управление перезагрузкой
- `tasks/limits.yaml` - системные лимиты
- `tasks/networkmanager.yaml` - настройка NetworkManager
- `tasks/resolv.yaml` - конфигурация DNS
- `tasks/swap.yaml` - отключение SWAP
- `tasks/ssh_keys.yaml` - SSH ключи
- `tasks/sysctl.yaml` - настройка sysctl
- `tasks/apt_nexus_repo.yaml` - настройка APT репозиториев
- `tasks/ipv6.yaml` - настройка IPv6
- `templates/chrony.conf.j2` - конфигурация chrony
- `templates/nexus_sources.list.j2` - шаблон Nexus sources.list
- `templates/sysctl.conf.j2` - шаблон sysctl.conf
- `templates/resolv.conf.j2` - шаблон resolv.conf
- `handlers/main.yaml` - обработчики событий

## Особенности

### DNS конфигурация
Роль создает статический `/etc/resolv.conf` и делает его неизменяемым для предотвращения перезаписи системными службами.

### SSH безопасность
Регенерация SSH host ключей повышает безопасность, особенно для клонированных виртуальных машин.

### Persistent логирование
Настройка persistent хранения journald обеспечивает сохранение системных логов после перезагрузки, что критично для диагностики проблем и аудита.

### Автоматическое управление SWAP
Роль автоматически определяет необходимость отключения SWAP на основе групп хостов. Это упрощает управление инфраструктурой и предотвращает ошибки конфигурации.

### Sysctl конфигурация
Роль настраивает системные параметры ядра для оптимизации производительности, создавая файл `/etc/sysctl.d/99-ubuntu-tuning.conf` и применяя их немедленно.

### APT репозитории
Роль позволяет перенаправить стандартные APT репозитории Ubuntu на проксируемый репозиторий Nexus, обеспечивая централизованное управление пакетами и ускоряя загрузку.

### Отключение IPv6
Роль позволяет полностью отключить IPv6 на сервере, что может быть полезно для упрощения сетевой конфигурации или повышения безопасности в средах, где IPv6 не используется.

## Зависимости

Нет зависимостей от других ролей.

## Автор

ASAP Team
