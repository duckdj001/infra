import os

import testinfra.utils.ansible_runner

testinfra_hosts = testinfra.utils.ansible_runner.AnsibleRunner(
    os.environ['MOLECULE_INVENTORY_FILE']).get_hosts('all')


def test_zabbix(host):
    s = host.service("zabbix-agent2")
    assert s.is_enabled
    assert s.is_running


def test_file(host):
    f = host.file("/etc/zabbix/zabbix_agent2.conf")
    assert f.is_file
    assert f.exists
    g = host.file("/etc/sudoers.d/30_zabbix_agent")
    assert g.exists
    assert g.user == "root"
    assert g.group == "root"
    assert g.mode == 0o440
    # x = host.file("/usr/local/bin/lld_disk.py")
    # assert x.exists
    # assert x.user == "root"
    # assert x.group == "root"
    # assert x.mode == 0o755
    # y = host.file("/etc/zabbix/zabbix_agentd.d/diskstats.conf")
    # assert y.exists
    # assert y.user == "root"
    # assert y.group == "zabbix"
    # assert y.mode == 0o644
