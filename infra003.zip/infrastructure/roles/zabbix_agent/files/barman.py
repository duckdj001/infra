#!/usr/bin/python3

import shutil
import json
import subprocess


class BarmanCollector:
    def __init__(self):
        self._barman_path = shutil.which('barman')
        self._data = {
            "servers": [],
            "checks": {},
            "collector_error": "",
        }

  def __call__(self):
    if self._barman_path is None:
      # barman not found
      self._data["collector_error"] = "barman not found in PATH"
      self._print_result()
      return

    try:
      self._data["servers"] = self._get_server_list()
    except Exception as e:
      # oh well...
      self._data["collector_error"] = "Error listing servers: %s" % str(e)
      self._print_result()
      return

    try:
      self._data["checks"] = self._get_checks()
    except Exception as e:
      self._data["collector_error"] = "Error getting checks statuses: %s" % str(e)

    self._print_result()

  def _print_result(self):
    print(json.dumps(self._data))

  def _get_server_list(self):
    result = subprocess.run([self._barman_path, "-f", "json", "list-server"],
      stdout=subprocess.PIPE)
    result.check_returncode()
    hash_list = json.loads(result.stdout)
    return list(hash_list.keys())

  def _get_checks(self):
    result = subprocess.run([self._barman_path, "-f", "json", "check", "all"],
      stdout=subprocess.PIPE)
    return json.loads(result.stdout)

if __name__ == "__main__":
  collector = BarmanCollector()
  collector()
