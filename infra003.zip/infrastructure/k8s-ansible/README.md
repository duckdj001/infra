# Kubernetes Cluster Playbooks

This repository contains a self-contained Ansible layout dedicated to provisioning and expanding a Kubernetes cluster with a clear separation between control plane and worker node workflows. All package repositories are consumed via the internal Nexus proxy and optional disk preparation is handled through the bundled `disk_management` role.

## Layout

- `ansible.cfg` – opinionated defaults (YAML output, pipelining) and inventory/roles paths
- `inventory/` – example static inventory and shared group variables with Nexus overrides
- `playbooks/master.yml` – installs common packages and initialises the control plane
- `playbooks/worker.yml` – prepares worker nodes and joins them to the cluster
- `roles/k8s_common` – common OS/kernel/container runtime configuration
- `roles/k8s_control_plane` – cluster initialisation, join token management, CNI tooling
- `roles/k8s_node` – worker join flow with automatic token bootstrap
- `roles/disk_management` – copy of the LVM role for optional data disk preparation

## Usage

1. Populate the inventory. You can follow the legacy layout via `inventory/10-local.yml` (same structure as в старом репозитории) or point `inventory/hosts.yml` to a smaller environment.
2. Adjust `inventory/group_vars/all.yml` to set Nexus endpoints and enable disk management if required.
3. Run the control plane playbook:
  ```bash
  ansible-playbook playbooks/master.yml -i inventory/10-local.yml
  ```
4. On success, provision workers:
  ```bash
  ansible-playbook playbooks/worker.yml -i inventory/10-local.yml
  ```

### Adding new nodes

- Additional masters: `ansible-playbook playbooks/master.yml -e k8s_cluster_init=false -e k8s_rejoin_masters=true`
- Additional workers: `ansible-playbook playbooks/worker.yml`

Set `k8s_refresh_worker_join=true` when you need to force regeneration of the worker join command before re-running the worker playbook.

### Disk management

Enable LVM preparation by setting `disk_management_enabled: true` in `group_vars/all.yml` and provide the required variables (`vg_name`, `lv_name`, `pvs`, `mountpoint`, etc.).
