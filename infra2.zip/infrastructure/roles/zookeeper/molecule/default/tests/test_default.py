import os

import testinfra.utils.ansible_runner

testinfra_hosts = testinfra.utils.ansible_runner.AnsibleRunner(
    os.environ['MOLECULE_INVENTORY_FILE']).get_hosts('all')


def test_hosts_file(host):
    f = host.file('/etc/hosts')

    assert f.exists
    assert f.user == 'root'
    assert f.group == 'root'


def test_zookeeper_service_running_and_enabled(host):
    service = host.service("zookeeper.service")
    assert service.is_running
    assert service.is_enabled


def test_zookeeper_port_listening(host):
    address = host.socket("tcp://0.0.0.0:2181")
    assert address.is_listening
