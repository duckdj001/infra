<a name="1.0.4"></a>
## 1.0.4 (2021-01-14)


#### Bug Fixes

*   Set zabbix-proxy should be started ([f58c239b](f58c239b))



<a name="1.0.3"></a>
## 1.0.3 (2021-01-11)


#### Bug Fixes

*   Remove debug info ([6d3b1bfa](6d3b1bfa))



<a name="1.0.2"></a>
## 1.0.2 (2021-01-11)


#### Bug Fixes

*   Idempotence issue ([8177d275](8177d275))



<a name="1.0.1"></a>
## 1.0.1 (2021-01-11)


#### Bug Fixes

*   Remove broken sqlite db file ([5329e00a](5329e00a))



<a name="1.0.0"></a>
## 1.0.0 (2020-12-18)


#### Features

*   Update CI, using shared CI ([1bf5b88c](1bf5b88c))
*   write readme, remove unused files ([5b33e365](5b33e365))
*   Molecule install docker-selinux ([4926e0b0](4926e0b0))
*   Fix CI ([00901af7](00901af7))
*   Add vars, color ([192efef3](192efef3))
*   Update molecule layout ([527c9a90](527c9a90))
*   Update molecule image ([e0dba142](e0dba142))
*   Add docker version ([e4431e46](e4431e46))
*   Fix tags ([ece64af7](ece64af7))
*   Fix yamllint ([f1cfcb7f](f1cfcb7f))
*   Update CI, requrements ([885f4a5f](885f4a5f))
*   Update image ([87c9d83c](87c9d83c))
*   Upload zabbbix role ([3f121e5a](3f121e5a))

#### Bug Fixes

*   Remove molecule Dockerfile ([3f68d33c](3f68d33c))
*   Remove unused components disable molecule debug ([a7a64a29](a7a64a29))
*   Change CI to docker-socket ([d6b3daaa](d6b3daaa))
*   Fix molecule default, change tags CI ([e4fc28c2](e4fc28c2))
*   Change gitlab CI to docker socket ([6b68853b](6b68853b))
*   Fix long line ([92a4f687](92a4f687))
*   change image ([27ba9575](27ba9575))
*   Change tag ([26b6e969](26b6e969))



<a name="0.0.1"></a>
## 0.0.1 (2019-11-20)


#### Bug Fixes

*   Change default version, fix some errors in README ([992406fa](992406fa))



<a name="0.1.1"></a>
## 0.1.1 (2019-03-07)


#### Features

*   add molecule requirements feat: add Makefile ([b4f5ac73](b4f5ac73))



