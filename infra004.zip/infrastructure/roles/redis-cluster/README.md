# redis-cluster
Redis Cluster - это распределенная реализация Redis обеспечивающая высокую производительность, линейную масштабируемость, шардирование, репликацию и обработку отказов. 

## Начиная использовать
Роль устанавливает и конфигурирует новый кластер.

## Настройка
Переменная | Значение по умолчанию | Описание
--- | --- | ---
`redis_manage_selinux` | false | управление selinux (добавление сетевых портов, файлового контекста)
`redis_node_address` | ansible_default_ipv4.address | адрес ноды 
`redis_nodes_ports` |  | порты на которых будут работать redis ноды
`redis_cluster_replicas` | 1 | количество реплик каждого мастера
`redis_parameter` | {} | [параметры конфигурации](https://raw.githubusercontent.com/redis/redis/6.0/redis.conf) redis
`redis_save` | {} | параметры сохранения RDB
`redis_acls` | [] | ACL записи

## Пример использования
### inventory.yaml
```
all:
  children:
    redis:
      hosts:
        node1:
          ansible_host: 192.168.88.232
        node2:
          ansible_host: 192.168.88.233
        node3:
          ansible_host: 192.168.88.234
```

### playbook.yaml
```
---
- hosts: redis
  vars:
    redis_nodes_ports:
      - 7000
      - 7001
    redis_parameter:
      appendonly: 'yes'
      always-show-logo: 'no'
    redis_save:
      3600: 1
      300: 100
      60: 10000
    redis_acls:
      - "user worker +@list +@connection ~jobs:* on >ffa9203c493aa99"
      - "user alice on +@all -DEBUG ~* >somepassword"
  roles:
    - redis-cluster

```
Разворачивает и запускает кластер из 6 логических нод на 3 физических. На каждой физической ноде запускаются мастер и слейв: A-C', B-A', C-B' соединенных по следующей схеме: A->A' B->B' C-C'. Возможны и другие конфигурации кластера в зависимости от кол-ва физических и логических нод, а также фактора репликации.

## Разработка

При начале разработки новой роли требуется настроить виртуальное окружение python:

```shell
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

Для возможности локального тестирования роли рекомендуется настроить виртуальное окружение, установив в него следующие пакеты:
```shell
pip install -r requirements_molecule.txt
```

Для версионирования используется система семантического версионирования (https://semver.org/lang/ru/)

Для использования автоматической генерации CHANGELOG.md требуется установить пакет clog

Для повышения патч-версии необходимо использовать команду
```shell
make patch
```

Для повышения минорной версии необходимо использовать команду
```shell
make minor
```

Для повышения мажорной версии необходимо использовать команду
```shell
make major
```

При выполнение данных команд в репозитории не должно быть никаких незафиксированных изменений.

При выполнение команды `make` будет также создан и сформирован файл CHANGELOG.md, формирование файла будет основано на
сделанных коммитах в репозитории.

Все коммиты должны следовать системе `conventional commit` https://www.conventionalcommits.org/en/v1.0.0/

Перед выпуском мажорной версии роли maintainer проекта проверят наличие заполненого описание роли в файле README.md

Повышение мажорной версии до 1 выполняется только в случае полной готовности роли по функционалу, успешного прохождения пайплайна в gitlab,
дальнейшее увеличение мажорной версии происходит только в случае обратно несовместимых изменений

Для подключения роли в плейбук применяемый к продуктивному окружению используется только стабильная версия роли.

## Документация
[Redis cluster](https://redis.io/topics/cluster-tutorial)

[Redis configuration parameters](https://raw.githubusercontent.com/redis/redis/6.0/redis.conf)

## Links
[Семантическое версионирование](https://semver.org/lang/ru/)
[Conventional commit](https://www.conventionalcommits.org/en/v1.0.0/)
[Общая директория с ролями ansible](https://git.alp.ru/ansible/roles)
