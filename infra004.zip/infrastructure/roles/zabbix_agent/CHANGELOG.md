<a name="1.2.8"></a>
## 1.2.8 (2021-02-05)


#### Bug Fixes

*   Remove tag always ([4dfe6e28](4dfe6e28))



<a name="1.2.7"></a>
## 1.2.7 (2021-01-20)




<a name="1.2.6"></a>
## 1.2.6 (2021-01-14)




<a name="1.2.5"></a>
## 1.2.5 (2020-12-29)


#### Bug Fixes

*   Set when for zabbix agent v1. set conf dir in template ([8b9c7c4c](8b9c7c4c))



<a name="1.2.4"></a>
## 1.2.4 (2020-12-29)


#### Bug Fixes

*   Set conf path for zabbix agent1 ([acb208c7](acb208c7))



<a name="1.2.3"></a>
## 1.2.3 (2020-12-29)


#### Features

*   Add zabbix_conf_dir for separate zabbix ([9d237e3c](9d237e3c))



<a name="1.2.2"></a>
## 1.2.2 (2020-12-29)


#### Features

*   Add Debian-like system support ([95aed61e](95aed61e))



<a name="1.2.1"></a>
## 1.2.1 (2020-12-28)


#### Features

*   Set metadata as dict ([9a79cf76](9a79cf76))



<a name="1.2.0"></a>
## 1.2.0 (2020-12-18)


#### Features

*   update role ([d981ede9](d981ede9))

#### Bug Fixes

*   correct versions ([d2700594](d2700594))



<a name="1.1.0"></a>
## 1.1.0 (2020-02-20)


#### Features

*   Add monitoring_hostname_prefix to zabbix agent conf ([44c895d9](44c895d9))



<a name="1.0.0"></a>
## 1.0.0 (2019-12-10)




<a name="0.3.0"></a>
## 0.3.0 (2019-12-06)




<a name="0.2.0"></a>
## 0.2.0 (2019-12-06)


#### Features

*   add meta and .bumpversion ([f3282adb](f3282adb))
*   add Makefile ([011ed173](011ed173))
*   Initial commit zabbix_agent ([cd1f2a81](cd1f2a81))

#### Bug Fixes

*   add empty file CHANGELOG.md ([44ab7d09](44ab7d09))
*   Change template for unpack dict ([67205282](67205282))



<a name="0.2.0"></a>
## 0.2.0 (2019-12-06)


#### Features

*   add meta and .bumpversion ([f3282adb](f3282adb))
*   add Makefile ([011ed173](011ed173))
*   Initial commit zabbix_agent ([cd1f2a81](cd1f2a81))

#### Bug Fixes

*   Change template for unpack dict ([67205282](67205282))



