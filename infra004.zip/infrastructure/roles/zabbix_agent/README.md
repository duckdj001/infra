Описание роли
=========

Роль zabbix_agent выполняет установку и настройку zabbix agent на целевой машине.
Дополнительная функциональность:
 - Добавлено низкоуровневое обнаружение дисков, в том числе разделов lvm
 - Добавлен сбор статистики по дискам на основе diskstats. Шаблон Zabbix `T-Linux Disk Performance`
 - Сбор статистики по использованию lvm. Шаблон Zabbix `T-Linux App LVM active`
 - Настройка политик SELinux   


Общая последовательность действий:
Добавляет репозиторий zabbix  
Устанавлиет zabbix-agent  
Копирует конфигурацию zabbix_agentd.conf  
Выполняет настройку sudo для zabbix agent
Копирует скрипт LLD Disk Discovery и конфигурацию diskstats.conf  
Создает SELinux модуль и устанавливает его  
Копирует конфигурацию rabe.lvm.conf  


Требования
------------
CentOS 7

Описание переменных
--------------
```yaml
---
zabbix_version: Версия zabbix
monitoring_port: Порт на котором работает мониторинг
monitoring_metadata:
```
Переменная monitoring_metadata содержит словарь, который используется в цикле for в jinja2 в шаблоне для конфигурационного файла zabbix.  
Эта строка в шаблоне позволяет распаковывать значения для ключа.  
```HostMetadata={% for k,v in monitoring_metadata.items() %}{{ k }}={{ v }};{% endfor %}```  
Таким образом в конфиге получаем:  
```HostMetadata=DC=RU-DEV-DTLN-1_NORD.3;OS=Linux;app=postgres;```

Зависимости
------------
Отсутствует

Примеры переменных:
---
```yaml
---
zabbix_version: 3.2
monitoring_port: 10050
monitoring_metadata:
      DC: RU-DEV-DTLN-1_NORD.3
      OS: Linux
      app: postgres

```

## Настройка

Первичная настройка роли представляет собой заполнение файла `meta/main.yml`, где указывается описание роли.
Описание роли должно быть кратким и однозначно трактовать функционал роли

## Разработка

Установка зависимых пакетов
--------------------------
```
sudo yum install epel-release
sudo yum install python36 python36-devel python36-pip gcc
sudo yum install -y yum-utils device-mapper-persistent-data lvm2
sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
sudo yum install docker-ce docker-ce-cli containerd.io
sudo systemctl start docker
```

Добавление пользователя в группу docker
---------------------------------------
Это позвлоляет запускать docker без повышения привелегий (sudo)  
```sudo usermod -aG docker $USER```  
Далее требуется перелогиниться в системе.  

При начале разработки новой роли требуется настроить виртуальное окружение python:

```shell
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

Для возможности локального тестирования роли рекомендуется настроить виртуальное окружение, установив в него следующие пакеты:
```shell
pip install -r requirements_molecule.txt
```

Для версионирования используется система семантического версионирования (https://semver.org/lang/ru/)

Для использования автоматической генерации CHANGELOG.md требуется установить пакет clog


Для повышения патч-версии необходимо использовать команду
```shell
make patch
```

Для повышения минорной версии необходимо использовать команду
```shell
make minor
```

Для повышения мажорной версии необходимо использовать команду
```shell
make major
```

При выполнение данных команд в репозитории не должно быть никаких незафиксированных изменений.

При выполнение команды `make` будет также создан и сформирован файл CHANGELOG.md, формирование файла будет основано на
сделанных коммитах в репозитории.

Все коммиты должны следовать системе `conventional commit` https://www.conventionalcommits.org/en/v1.0.0/

Перед выпуском мажорной версии роли maintainer проекта проверят наличие заполненого описание роли в файле README.md

Повышение мажорной версии до 1 выполняется только в случае полной готовности роли по функционалу, успешного прохождения пайплайна в gitlab,
дальнейшее увеличение мажорной версии происходит только в случае обратно несовместимых изменений

Для подключения роли в плейбук применяемый к продуктивному окружению используется только стабильная версия роли.


## Links
[Семантическое версионирование](https://semver.org/lang/ru/)
[Conventional commit](https://www.conventionalcommits.org/en/v1.0.0/)
