# metro-search-node

Search нода METRO-CC. Роль устанавливает и конфигурирует nginx, php-fpm, создает пользователя и каталог для работы приложения.

## Переменные

Переменная | Значение по умолчанию | Описание
--- | --- | ---
`metro_search_node_app_user` | search | пользователь под которым работает приложение
`metro_search_node_app_group` | search | группа для работы php-fpm
`metro_search_nginx_server_name` | _ | имя сервера в nginx
`metro_search_nginx_server_root` | /opt/search/app | web каталог приложения
`metro_search_node_php_repo` | remi-php74 | Репозиторий php
`metro_search_node_disable_robots` | true | Запретить индексацию поисковиками
`metro_search_node_db_name` | search | Имя БД
`metro_search_node_db_user` | search | Имя пользователя для доступа к БД
`metro_search_node_db_password` |  | Пароль пользователя БД

## Пример использования

```
---
- name: Search nodes
  hosts: sphinx
  roles:
    - role: metro-search-node
```

## Разработка

При начале разработки новой роли требуется настроить виртуальное окружение python:

```shell
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

Для возможности локального тестирования роли рекомендуется настроить виртуальное окружение, установив в него следующие пакеты:
```shell
pip install -r requirements_molecule.txt
```

Для версионирования используется система семантического версионирования (https://semver.org/lang/ru/)

Для использования автоматической генерации CHANGELOG.md требуется установить пакет clog

Для повышения патч-версии необходимо использовать команду
```shell
make patch
```

Для повышения минорной версии необходимо использовать команду
```shell
make minor
```

Для повышения мажорной версии необходимо использовать команду
```shell
make major
```

При выполнение данных команд в репозитории не должно быть никаких незафиксированных изменений.

При выполнение команды `make` будет также создан и сформирован файл CHANGELOG.md, формирование файла будет основано на
сделанных коммитах в репозитории.

Все коммиты должны следовать системе `conventional commit` https://www.conventionalcommits.org/en/v1.0.0/

Перед выпуском мажорной версии роли maintainer проекта проверят наличие заполненого описание роли в файле README.md

Повышение мажорной версии до 1 выполняется только в случае полной готовности роли по функционалу, успешного прохождения пайплайна в gitlab,
дальнейшее увеличение мажорной версии происходит только в случае обратно несовместимых изменений

Для подключения роли в плейбук применяемый к продуктивному окружению используется только стабильная версия роли.


## Links
[Семантическое версионирование](https://semver.org/lang/ru/)
[Conventional commit](https://www.conventionalcommits.org/en/v1.0.0/)
[Общая директория с ролями ansible](https://git.alp.ru/ansible/roles)