import os

import testinfra.utils.ansible_runner

testinfra_hosts = testinfra.utils.ansible_runner.AnsibleRunner(
    os.environ['MOLECULE_INVENTORY_FILE']).get_hosts('all')

patroni_version = "1.6.4"


def test_binary(host):
    f = host.file('/opt/patroni/venv/bin/patroni')

    assert f.exists


def test_service(host):
    s = host.service('patroni')

    assert s.is_running
    assert s.is_enabled


def test_firewalld(host):
    ports = '5532/tcp'

    out = host.check_output('firewall-cmd --list-ports')
    assert out == ports

    out = host.check_output('firewall-cmd --list-ports --permanent')
    assert out == ports


def test_dcs(host):
    dcs_expected = """loop_wait: 10
master_start_timeout: 300
maximum_lag_on_failover: 1048576
postgresql:
  parameters:
    hot_standby: 'on'
    wal_level: replica
    wal_log_hints: 'on'
  use_pg_rewind: true
  use_slots: true
retry_timeout: 10
ttl: 30"""

    out = host.check_output('LC_ALL=en_US.utf8 /opt/patroni/venv/bin/patronictl \
        -c /opt/patroni/patroni.yaml show-config')
    assert out == dcs_expected
