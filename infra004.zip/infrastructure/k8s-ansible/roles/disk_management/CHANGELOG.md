<a name="1.1.0"></a>
## 1.1.0 (2021-03-29)


#### Features

*   more required packages ([43aef750](43aef750))
*   universal package installation ([142979c2](142979c2))



