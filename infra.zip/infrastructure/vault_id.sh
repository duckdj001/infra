#!/bin/bash

vault_password.sh metro
