#!/usr/bin/python3

import argparse
import json
import os
import subprocess
import sys

RESTIC_BIN_PATH = os.environ.get('RESTIC_BIN_PATH', '/usr/local/bin/restic.sh')
RESTIC_BACKUP_FILES_PATH = os.environ.get('RESTIC_BACKUP_FILES_PATH',
                                          '/etc/restic')


class ResticCollector:
    def __init__(self):
        self._restic_bin_path = RESTIC_BIN_PATH
        self._restic_backup_files_path = RESTIC_BACKUP_FILES_PATH

    def __call__(self, *args, **kwargs):
        return

    def discovery_backups(self):
        files = [f for f in os.listdir(self._restic_backup_files_path)
                 if f.endswith('.files')]
        backup_names = []
        for file in files:
            backup_names.append({
                '{#RESTIC_BACKUP}': file.split('.')[0]
            })

        return json.dumps(backup_names)

    def get_backup_info(self, backup):
        result = subprocess.run([self._restic_bin_path,
                                 backup,
                                 "snapshots",
                                 "--json"], stdout=subprocess.PIPE)
        return json.dumps(json.loads(result.stdout)[-1])


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('-d', '--discovery', action='store_true')
    parser.add_argument('-b', '--backup', action='store')
    args = parser.parse_args()

    collector = ResticCollector()
    collector()

    if args.discovery:
        print(collector.discovery_backups())
        sys.exit(0)

    if args.backup:
        print(collector.get_backup_info(args.backup))
