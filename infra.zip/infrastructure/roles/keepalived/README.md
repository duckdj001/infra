keepalived
=========

Выполняет установку и настройку keepalived

Requirements
------------

Роль для CetnOS 7

Role Variables
--------------

{{ keepalived_interface }} - имя внешнего интерфейса
{{ keepalived_instanse }} - keepalived vrrp_instance
{{ keepalived_master_hostname }} - имя мастера
{{ keepalived_priority }} - приоритет ноды устанавливается в hostvars для каждого сервера
{{ keepalived_virtual_address }} - виртульный адрес с которого будут доступны сервисы
{{ keepalived_password }} - пароль для keepalived

Example Playbook
----------------


    - hosts: lb
      roles:
         - role: keepalived
           keepalived_instanse: VI_1
           keepalived_master_hostname: mosnlb200vm.digital.kfc.ru
           keepalived_virtual_address: 195.14.100.110/29

hostvars/mosnlb200vm.digital.kfc.ru
keepalived_priority: 100

License
-------

BSD

Author Information
------------------

