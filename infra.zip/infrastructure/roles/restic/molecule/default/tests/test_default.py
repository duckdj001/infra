import os

import testinfra.utils.ansible_runner
import pytest
import json

testinfra_hosts = testinfra.utils.ansible_runner.AnsibleRunner(
    os.environ['MOLECULE_INVENTORY_FILE']).get_hosts('instance')


def test_restic_bin(host):
    f = host.file('/opt/restic/restic_0.11.0')

    assert f.exists
    assert f.user == 'root'
    assert f.group == 'root'


@pytest.mark.parametrize("name", ["default", "s3"])
def test_conf_file(host, name):
    files = [f'/etc/restic/{name}.files', f'/etc/restic/{name}.env']

    for file in files:
        assert host.file(file).exists


@pytest.mark.parametrize("name", ["default", "s3"])
@pytest.mark.parametrize("service", ["restic", "restic-prune"])
def test_restic_timer_running_and_enabled(host, name, service):
    service = host.service(f"{service}@{name}.timer")
    assert service.is_running
    assert service.is_enabled


@pytest.mark.parametrize("name", ["default", "s3"])
@pytest.mark.parametrize("service", ["restic", "restic-prune"])
def test_start_restic_services(host, name, service):
    service = host.run(f"systemctl start {service}@{name}.service")
    assert service.rc == 0

    backup_result = host.run(
        f"/usr/local/bin/restic.sh {name} snapshots --json")
    assert backup_result.rc == 0
    snapshots = json.loads(backup_result.stdout)
    assert len(snapshots) > 0
