# Пример запуска плейбука установки антивирусного ПО	
```sh
ansible-playbook playbook_kaspersky.yaml -i inventory/staging/10-local.yaml --vault-id @vault_id.sh --limit "msc-itg-k8sn-02v.metro" -u username
```