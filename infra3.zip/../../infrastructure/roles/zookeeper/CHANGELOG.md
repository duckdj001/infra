<a name="0.1.0"></a>
## 0.1.0 (2021-03-17)


#### Features

*   update Readme ([6d7e681f](6d7e681f))
*   add new variables and update README ([5758ae5a](5758ae5a))
*   add stop service command ([6a6e5f13](6a6e5f13))
*   replace path at variables ([b1ac05e2](b1ac05e2))
*   configure role ([e6a366ac](e6a366ac))

#### Bug Fixes

*   Remane meta/main ([4d2f288e](4d2f288e))
*   Change to group vars ([c8bb0341](c8bb0341))
*   zookeeper_host_name ([8eb1f920](8eb1f920))
*   fix variables ([6d7658b3](6d7658b3))
*   change java jdk version ([62f95c75](62f95c75))



<a name="0.0.1"></a>
## 0.0.1 (2019-11-20)


#### Bug Fixes

*   Change default version, fix some errors in README ([992406fa](992406fa))



<a name="0.1.1"></a>
## 0.1.1 (2019-03-07)


#### Features

*   add molecule requirements feat: add Makefile ([b4f5ac73](b4f5ac73))



