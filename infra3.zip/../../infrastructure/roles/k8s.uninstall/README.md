# k8s.uninstall role

This role removes Kubernetes components, container runtime configuration, CNI addons, and repository definitions that are provisioned by `k8s.install`.

## Usage

```yaml
- hosts: k8s_cluster
  become: true
  roles:
    - role: k8s.uninstall
```

Ensure the same variables used for `k8s.install` (such as repository URLs and manifest destinations) remain available when running this role so cleanup can match the install configuration.
