# percona-xtradb-cluster
Percona XtraDB Cluster is a fully open-source high-availability solution for MySQL. It integrates Percona Server and Percona XtraBackup with the Galera library to enable synchronous multi-source replication.

## Начиная использовать
Роль устанавливает и конфигурирует кластер с нуля (bootstrap), либо добавляет новые ноды в уже существующий кластер.

## Настройка
Переменная | Значение по умолчанию | Описание
--- | --- | ---
`encrypt_replication` | `true` | шифровать трафик server-server
`encrypt_client_server` | `false` | шифровать трафик client-server
`mysql_root_password` | | пароль mysql пользователя root
`client_socket` | `/var/lib/mysql/mysql.sock` |
`client_include` | `{}` | словарь переменных для включения в секцию [client]
`mysqld_server_id` | `1` | идентификатор сервера (при master/slave репликации)
`mysqld_datadir` |  | каталог данных mysql
`mysqld_log_error` | `/var/log/mysqld.log` | лог ошибок
`mysqld_pid_file` | `/var/run/mysqld/mysqld.pid` |
`mysqld_socket` | `/var/lib/mysql/mysql.sock` |
`mysqld_binlog_expire_logs_seconds` | `604800` | Срок хранения бинлогов (сек)
`wsrep_provider` | `/usr/lib64/galera4/libgalera_smm.so` | путь к библиотеке Galera
`wsrep_cluster_address` | ansible_default_ipv4.address нод входящих в кластер | заполняется автоматически из инвентори
`wsrep_cluster_name` | `my_wsrep_cluster` | имя кластера
`wsrep_node_name` | имя хоста | имя ноды
`wsrep_slave_threads` | 8 | Количество параллельных потоков применяющих транзакции репликации
`pxc_strict_mode` | `ENFORCING` | DISABLED,PERMISSIVE,ENFORCING,MASTER режим работы кластера
`mysqld_include` | `{}` | словарь переменных для включения в секцию [mysqld]

## Пример использования
### inventory.yaml
```
all:
  children:
    pxc:
      hosts:
        node1:
          ansible_host: 192.168.88.232
        node2:
          ansible_host: 192.168.88.233
        node3:
          ansible_host: 192.168.88.234
```

### playbook.yaml
```
---
- hosts: pxc
  vars:
    wsrep_cluster_name: pxc-cluster
    mysql_root_password: chexa7Th
  roles:
    - percona-xtradb-cluster

```
Разворачивает и запускает кластер с именем pxc-cluster из трёх нод и паролем mysql пользователя root: chexa7Th

## Разработка

При начале разработки новой роли требуется настроить виртуальное окружение python:

```shell
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

Для возможности локального тестирования роли рекомендуется настроить виртуальное окружение, установив в него следующие пакеты:
```shell
pip install -r requirements_molecule.txt
```

Для версионирования используется система семантического версионирования (https://semver.org/lang/ru/)

Для использования автоматической генерации CHANGELOG.md требуется установить пакет clog

Для повышения патч-версии необходимо использовать команду
```shell
make patch
```

Для повышения минорной версии необходимо использовать команду
```shell
make minor
```

Для повышения мажорной версии необходимо использовать команду
```shell
make major
```

При выполнение данных команд в репозитории не должно быть никаких незафиксированных изменений.

При выполнение команды `make` будет также создан и сформирован файл CHANGELOG.md, формирование файла будет основано на
сделанных коммитах в репозитории.

Все коммиты должны следовать системе `conventional commit` https://www.conventionalcommits.org/en/v1.0.0/

Перед выпуском мажорной версии роли maintainer проекта проверят наличие заполненого описание роли в файле README.md

Повышение мажорной версии до 1 выполняется только в случае полной готовности роли по функционалу, успешного прохождения пайплайна в gitlab,
дальнейшее увеличение мажорной версии происходит только в случае обратно несовместимых изменений

Для подключения роли в плейбук применяемый к продуктивному окружению используется только стабильная версия роли.

## Документация
[https://www.percona.com/doc/percona-xtradb-cluster/8.0/index.html]

## Links
[Семантическое версионирование](https://semver.org/lang/ru/)
[Conventional commit](https://www.conventionalcommits.org/en/v1.0.0/)
[Общая директория с ролями ansible](https://git.alp.ru/ansible/roles)