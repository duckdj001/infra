# postgresql.manage

Управление postgresql.


## Начиная использовать

```yaml
---
postgresql_version: Версия PostgreSQL
postgresql_data_dir: Путь к директории PostgreSQL с базами
postgresql_bin_path: Путь к исполняемым файлам PostgreSQL
postgresql_config_path: Путь к директории PostgreSQL с файлами конфигураций
postgresql_restarted_state: Действие для сервисов по умолчанию
postgresql_main_config_filename: Имя главного конфигурационного файла

postgresql_python_library: Python библиотека для взаимодействия с PostgreSQL
postgresql_user: Пользователь PostgreSQL
postgresql_group: Группа PostgreSQL

postgresql_initdb_enabled: Включение инициализации PostgreSQL (boolean)
postgresql_initdb_param: Параметры инициализации PostgreSQL

postgresql_unix_socket_directories: Путь к сокету для локального подключения

postgresql_service_enabled: Включен ли сервис PostgreSQL (boolean)

# Global configuration options that will be set in postgresql.conf.
postgresql_connections: Количество подключений к PostgreSQL
postgresql_global_config_options: Дополнительные параметры конфигурации (dict)

postgresql_hba_enabled: Включена ли Host based authentication (boolean)
# Host based authentication (hba) entries to be added to the pg_hba.conf. This
# variable's defaults reflect the defaults that come with a fresh installation.
postgresql_hba_entries: Записи в Host based authentication (list of dict)
  - type: Тип подключения
    database: Имена баз данных
    user: Логин пользователя
    auth_method: Метод подключения


# Debian only. Used to generate the locales used by PostgreSQL databases.
postgresql_locales: Определение локали PostgreSQL по умолчанию (list)

# Databases to ensure exist.
postgresql_databases: Список баз, которые будут созданы
  - name: Имя базы # required; the rest are optional
    lc_collate: Порядок сортировки строк # defaults to 'en_US.UTF-8'
    lc_ctype: Классификация символов # defaults to 'en_US.UTF-8'
    encoding: Кодировка # defaults to 'UTF-8'
    template: Шаблон # defaults to 'template0'
    login_host: Хост для подключения # defaults to 'localhost'
    login_password: Пароль пользователя для подключения # defaults to not set
    login_user: Логин пользователя для подключения # defaults to '{{ postgresql_user }}'
    login_unix_socket: Путь к сокету для локальных подключения # defaults to 1st of postgresql_unix_socket_directories
    port: Порт # defaults to not set
    owner: Владелец базы # defaults to postgresql_user
    state: Текущее состояние базы # defaults to 'present'
https://docs.ansible.com/ansible/latest/modules/postgresql_db_module.html

# Users to ensure exist.
postgresql_users: Список пользователей
  - name: Логин пользователя #required; the rest are optional
    password: Пароль пользователя # defaults to not set
    encrypted: Хранить пароль в захешированном виде # defaults to not set
    priv: Список привилегий пользователя разделенных символом '/'
    role_attr_flags: Аттрибуты пользователя PostgreSQL разделенных символом ',' # defaults to not set
    db: Имя базы для подключения, к которой будут предоставлены права # defaults to not set
    login_host: Хост для подключения # defaults to 'localhost'
    login_password: Пароль пользователя для подключения # defaults to not set
    login_user: Логин пользователя для подключения # defaults to '{{ postgresql_user }}'
    login_unix_socket: Путь к сокету для локальных подключения # defaults to 1st of postgresql_unix_socket_directories
    port: Порт # defaults to not set
    state: Текущее состояние пользователя # defaults to 'present'

postgresql_timescale: Включена ли поддержка timescale (boolean)
timescale_ext: Расширения timescale (list)
timescale_db: Имя базы данных

# postgresql.conf params

postgresql_timezone: Временная зона PostgreSQL
postgresql_locale_messages: Язык сообщений
postgresql_search_config: Конфигурация текстового поиска
postgresql_locks:  В один момент времени может быть заблокировано не больше этого числа различных объектов
postgresql_shared_preload_libraries: Список расширений PostgreSQL (list)
postgresql_cpu_operator_cost: Задаёт приблизительную стоимость обработки оператора или функции при выполнении запроса
postgresql_random_page_cost: Задаёт приблизительную стоимость чтения одной произвольной страницы с диска
postgresql_seq_page_cost: Задаёт приблизительную стоимость чтения одной страницы с диска, которое выполняется в серии последовательных чтений
postgresql_default_statistics_target: Устанавливает целевое ограничение статистики по умолчанию, распространяющееся на столбцы, для которых командой ALTER TABLE SET STATISTICS не заданы отдельные ограничения
postgresql_max_wal_size: Максимальный размер, до которого может вырастать WAL между автоматическими контрольными точками в WAL
postgresql_max_wal_senders: Задаёт максимально допустимое число одновременных подключений ведомых серверов или клиентов потокового копирования
postgresql_max_replication_slots: Задаёт максимальное число слотов репликации
postgresql_wal_keep_segments: Задаёт минимальное число файлов прошлых сегментов журнала, которые будут сохраняться в каталоге pg_wal, чтобы ведомый сервер мог выбрать их при потоковой репликации
postgresql_wal_log_hints: Когда этот параметр имеет значение on, сервер Postgres Pro записывает в WAL всё содержимое каждой страницы при первом изменении этой страницы после контрольной точки, даже при второстепенных изменениях так называемых вспомогательных битов
postgresql_checkpoint_timeout: Максимальное время между автоматическими контрольными точками в WAL.
postgresql_checkpoint_completion_target: Задаёт целевое время для завершения процедуры контрольной точки, как коэффициент для общего времени между контрольными точками
postgresql_maintenance_work_mem: Задаёт максимальный объём памяти для операций обслуживания БД, в частности VACUUM, CREATE INDEX и ALTER TABLE ADD FOREIGN KEY.
postgresql_temp_buffers: Задаёт максимальный объём памяти, выделяемой для временных буферов в каждом сеансе.
postgresql_effective_io_concurrency: Задаёт допустимое число параллельных операций ввода/вывода, которое говорит Postgres Pro о том, сколько операций ввода/вывода могут быть выполнены одновременно
postgresql_archive_mode: Когда параметр archive_mode включён, полные сегменты WAL передаются в хранилище архива командой archive_command
postgresql_archive_command: Команда локальной оболочки, которая будет выполняться для архивации завершённого сегмента WAL.
postgresql_archive_timeout: Для ограничения времени существования неархивированных данных можно установить значение archive_timeout, чтобы сервер периодически переключался на новый файл сегмента WAL. Когда этот параметр больше нуля, сервер будет переключаться на новый файл сегмента, если с момента последнего переключения на новый файл прошло заданное время и наблюдалась какая-то активность базы данных, даже если это была просто контрольная точка

```

## Пример использования

```yaml
postgresql_version: "11"
postgresql_data_dir: "/var/lib/pgsql/{{postgresql_version}}/data"
postgresql_bin_path: "/usr/pgsql-{{ postgresql_version }}/bin/"
postgresql_config_path: "/var/lib/pgsql/{{postgresql_version}}/data"
postgresql_restarted_state: "reloaded"
postgresql_main_config_filename: postgresql.conf

postgresql_python_library: python-psycopg2
postgresql_user: postgres
postgresql_group: postgres

postgresql_initdb_enabled: true
postgresql_initdb_param:
  - '--data-checksums'
  - '--locale ru_RU.UTF-8'

postgresql_unix_socket_directories:
  - /var/run/postgresql

postgresql_service_enabled: true

# Global configuration options that will be set in postgresql.conf.
postgresql_connections: 300
postgresql_global_config_options:
  unix_socket_directories: " '{{ postgresql_unix_socket_directories \
| join(',') }}' "


postgresql_hba_enabled: true
# Host based authentication (hba) entries to be added to the pg_hba.conf. This
# variable's defaults reflect the defaults that come with a fresh installation.
postgresql_hba_entries:
  - type: local
    database: all
    user: postgres
    auth_method: peer
  - type: local
    database: all
    user: all
    auth_method: peer
  - type: host
    database: all
    user: all
    address: '127.0.0.1/32'
    auth_method: md5
  - type: host
    database: all
    user: all
    address: '::1/128'
    auth_method: md5

# Debian only. Used to generate the locales used by PostgreSQL databases.
postgresql_locales:
  - 'en_US.UTF-8'

# Databases to ensure exist.
postgresql_databases: []
# - name: exampledb # required; the rest are optional
#   lc_collate: # defaults to 'en_US.UTF-8'
#   lc_ctype: # defaults to 'en_US.UTF-8'
#   encoding: # defaults to 'UTF-8'
#   template: # defaults to 'template0'
#   login_host: # defaults to 'localhost'
#   login_password: # defaults to not set
#   login_user: # defaults to '{{ postgresql_user }}'
#   login_unix_socket: # defaults to 1st of postgresql_unix_socket_directories
#   port: # defaults to not set
#   owner: # defaults to postgresql_user
#   state: # defaults to 'present'

# Users to ensure exist.
postgresql_users: []
# - name: jdoe #required; the rest are optional
#   password: # defaults to not set
#   encrypted: # defaults to not set
#   priv: # defaults to not set
#   role_attr_flags: # defaults to not set
#   db: # defaults to not set
#   login_host: # defaults to 'localhost'
#   login_password: # defaults to not set
#   login_user: # defaults to '{{ postgresql_user }}'
#   login_unix_socket: # defaults to 1st of postgresql_unix_socket_directories
#   port: # defaults to not set
#   state: # defaults to 'present'

postgresql_timescale: false
timescale_ext:
  - timescaledb
timescale_db: ''

# postgresql.conf params

postgresql_timezone: UTC
postgresql_locale_messages: en_US.UTF-8
postgresql_locale: ru_RU.UTF-8
postgresql_search_config: pg_catalog.russian
postgresql_locks: 64
postgresql_shared_preload_libraries:
  - pg_stat_statements
  - pg_buffercache
postgresql_cpu_operator_cost: 0.00025
postgresql_random_page_cost: 1
postgresql_seq_page_cost: 1
postgresql_default_statistics_target: 1000
postgresql_max_wal_size: 2048
postgresql_max_wal_senders: 12
postgresql_max_replication_slots: 10
postgresql_wal_keep_segments: 64
postgresql_wal_log_hints: 'on'
postgresql_checkpoint_timeout: 5min
postgresql_checkpoint_completion_target: 0.9
postgresql_maintenance_work_mem: 512
postgresql_temp_buffers: 128
postgresql_effective_io_concurrency: 100
postgresql_archive_mode: ''
postgresql_archive_command: ''
postgresql_archive_timeout: 5min
```

## Разработка

При начале разработки новой роли требуется настроить виртуальное окружение python:

```shell
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

Для возможности локального тестирования роли рекомендуется настроить виртуальное окружение, установив в него следующие пакеты:
```shell
pip install -r requirements_molecule.txt
```

Для версионирования используется система семантического версионирования (https://semver.org/lang/ru/)

Для использования автоматической генерации CHANGELOG.md требуется установить пакет clog

Для повышения патч-версии необходимо использовать команду
```shell
make patch
```

Для повышения минорной версии необходимо использовать команду
```shell
make minor
```

Для повышения мажорной версии необходимо использовать команду
```shell
make major
```

При выполнение данных команд в репозитории не должно быть никаких незафиксированных изменений.

При выполнение команды `make` будет также создан и сформирован файл CHANGELOG.md, формирование файла будет основано на
сделанных коммитах в репозитории.

Все коммиты должны следовать системе `conventional commit` https://www.conventionalcommits.org/en/v1.0.0/

Перед выпуском мажорной версии роли maintainer проекта проверят наличие заполненого описание роли в файле README.md

Повышение мажорной версии до 1 выполняется только в случае полной готовности роли по функционалу, успешного прохождения пайплайна в gitlab,
дальнейшее увеличение мажорной версии происходит только в случае обратно несовместимых изменений

Для подключения роли в плейбук применяемый к продуктивному окружению используется только стабильная версия роли.


## Links
[Семантическое версионирование](https://semver.org/lang/ru/)
[Conventional commit](https://www.conventionalcommits.org/en/v1.0.0/)
[Общая директория с ролями ansible](https://git.alp.ru/ansible/roles)
