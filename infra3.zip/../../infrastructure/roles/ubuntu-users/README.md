# Ubuntu Users Role

Роль для управления пользователями и настройки SSH безопасности на Ubuntu серверах.

## Описание

Эта роль выполняет:
- Создание административных групп
- Создание пользователей с правами sudo
- Настройка SSH ключей для пользователей
- Удаление заблокированных пользователей
- Конфигурация SSH безопасности

## Требования

- Ubuntu 22.04 (Jammy) или Ubuntu 24.04 (Noble)
- Права sudo на целевых хостах
- Ansible 2.9+
- SSH публичные ключи в директории files/ роли

## Переменные

| Переменная | Значение по умолчанию | Описание |
|------------|----------------------|----------|
| `ubuntu_admin_groups` | [sudo, systemd-journal] | Административные группы |
| `ubuntu_admin_users` | [] | Список пользователей для создания |
| `ubuntu_blocked_users` | [] | Список пользователей для удаления |
| `ubuntu_ssh_password_auth` | false | Разрешить аутентификацию по паролю |
| `ubuntu_ssh_pubkey_auth` | true | Разрешить аутентификацию по ключам |
| `ubuntu_ssh_root_login` | false | Разрешить вход root |
| `ubuntu_ssh_permit_empty_passwords` | false | Разрешить пустые пароли |
| `ubuntu_restart_ssh` | true | Перезапускать SSH сервис |

## SSH ключи

SSH ключи находятся в директории `files/` роли:
```
infrastructure/roles/ubuntu-users/files/
├── username1.pub
├── username2.pub
└── [другие ключи...]
```

Имена файлов должны соответствовать именам пользователей в `ubuntu_admin_users`.

## Использование

### Базовое использование
```yaml
---
- name: Configure users
  hosts: ubuntu_servers
  become: true
  vars:
    ubuntu_admin_users:
      - admin
      - developer
  roles:
    - ubuntu-users
```

### С блокировкой пользователей
```yaml
---
- name: Manage users
  hosts: ubuntu_servers
  become: true
  vars:
    ubuntu_admin_users:
      - newadmin
    ubuntu_blocked_users:
      - oldadmin
      - tempuser
  roles:
    - ubuntu-users
```

### Только SSH настройки
```bash
ansible-playbook playbook.yml --tags ssh-security
```

## Теги

- `ubuntu-users` - все задачи роли
- `ssh-security` - только SSH настройки

## Безопасность SSH

Роль автоматически настраивает:
- `PasswordAuthentication no` - отключает пароли
- `PubkeyAuthentication yes` - включает ключи
- `PermitRootLogin no` - запрещает вход root
- `PermitEmptyPasswords no` - запрещает пустые пароли

## Файлы

- `tasks/main.yaml` - основные задачи
- `tasks/ssh_config.yaml` - настройка SSH
- `handlers/main.yaml` - обработчики событий
- `files/*.pub` - SSH публичные ключи пользователей
- `defaults/main.yaml` - переменные по умолчанию

## Доступные SSH ключи

В роли доступны ключи для следующих пользователей:
- admin-alopatin.pub
- admin-asukhovetchenko.pub
- admin-igolubkov.pub
- admin-mcc.pub
- admin-vkalinin.pub
- arytsevadm.pub
- dobryninadm.pub
- gavrilenkoadm.pub
- golubkovadm.pub
- hrapovadm.pub
- katuninadm.pub
- khrapovadm.pub
- kiyaevadm.pub
- kurdiukovadm.pub
- lopatinadm.pub
- maksimovadm.pub
- maksutovadm.pub
- rytsevadm.pub
- schetinkinadm.pub
- shmyrovadm.pub
- vladislav.kurdiukov.pub
- vtorushinadm.pub
- yakovlevadm.pub

## Структура роли

```
infrastructure/roles/ubuntu-users/
├── README.md
├── defaults/main.yaml
├── tasks/
│   ├── main.yaml
│   └── ssh_config.yaml
├── handlers/main.yaml
└── files/
    └── [SSH ключи пользователей...]
```

## Зависимости

Нет зависимостей от других ролей.

## Автор

ASAP Team
