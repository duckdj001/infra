# ubuntu-monitoring

Эта роль Ansible устанавливает и настраивает Node Exporter на системах Ubuntu 20.04.

## Требования

*   Ubuntu 20.04 или выше.
*   Python 3.x.

## Переменные роли

### Node Exporter

*   `install_node_exporter`: Устанавливать ли Node Exporter (по умолчанию: `true`).
*   `node_exporter_version`: Версия Node Exporter для установки (по умолчанию: `1.8.1`).
*   `node_exporter_download_url`: URL для загрузки архива Node Exporter. По умолчанию используется прокси-репозиторий Nexus.
    *   Пример: `https://nexus.metro-cc.ru/repository/github-raw-proxy/prometheus/node_exporter/releases/download/v{{ node_exporter_version }}/node_exporter-{{ node_exporter_version }}.linux-amd64.tar.gz`
*   `node_exporter_install_dir`: Директория для установки бинарного файла Node Exporter (по умолчанию: `/usr/local/bin`).
*   `node_exporter_user`: Пользователь, от имени которого будет запускаться Node Exporter (по умолчанию: `node_exporter`).
*   `node_exporter_group`: Группа, от имени которой будет запускаться Node Exporter (по умолчанию: `node_exporter`).
*   `node_exporter_listen_address`: Адрес и порт, на котором Node Exporter будет слушать (по умолчанию: `:9100`).
*   `node_exporter_extra_args`: Дополнительные аргументы для Node Exporter (по умолчанию: `""`).

### Zabbix Agent

*   `install_zabbix_agent`: Устанавливать ли Zabbix Agent (по умолчанию: `true`).
*   `zabbix_agent_version`: Версия Zabbix Agent для установки (по умолчанию: `"6.0"`).
*   `zabbix_repo_content`: Содержимое файла репозитория Zabbix (по умолчанию: `"deb https://nexus.metro-cc.ru/repository/apt-zabbix-proxy/zabbix/{{ zabbix_agent_version }}/ubuntu noble main"`).
*   `zabbix_server_ip`: IP-адрес или hostname Zabbix Server (по умолчанию: `"127.0.0.1"`).
*   `zabbix_server_active_ip`: IP-адрес или hostname Zabbix Server для активных проверок (по умолчанию: `"127.0.0.1"`).
*   `zabbix_hostname`: Имя хоста для Zabbix Agent (по умолчанию: `{{ inventory_hostname }}`).
*   `zabbix_agent_listen_port`: Порт, на котором Zabbix Agent будет слушать (по умолчанию: `10050`).
*   `zabbix_agent_log_file`: Путь к файлу логов Zabbix Agent (по умолчанию: `"/var/log/zabbix/zabbix_agent.log"`).
*   `zabbix_agent_log_file_size`: Максимальный размер файла логов в МБ (по умолчанию: `10`).
*   `zabbix_agent_debug_level`: Уровень отладки Zabbix Agent (по умолчанию: `3`).
*   `zabbix_agent_timeout`: Таймаут для Zabbix Agent (по умолчанию: `30`).
*   `zabbix_agent_include_dir`: Директория для дополнительных конфигурационных файлов Zabbix Agent (по умолчанию: `"/etc/zabbix/zabbix_agentd.d"`).
*   `zabbix_agent_plugins_dir`: Директория для плагинов Zabbix Agent (по умолчанию: `"/usr/lib/zabbix/modules"`).
*   `zabbix_agent_pid_file`: Путь к PID файлу Zabbix Agent (по умолчанию: `"/run/zabbix/zabbix_agent.pid"`).
*   `zabbix_agent_config_file`: Путь к основному конфигурационному файлу Zabbix Agent (по умолчанию: `"/etc/zabbix/zabbix_agentd.conf"`).
*   `zabbix_agent_state`: Состояние сервиса Zabbix Agent (по умолчанию: `started`).
*   `zabbix_agent_enabled`: Включен ли автозапуск сервиса Zabbix Agent (по умолчанию: `yes`).
*   `zabbix_monitoring_client`: Значение для HostMetadataItem (по умолчанию: `""`).
*   `zabbix_monitoring_metadata`: Список строк для HostMetadata (по умолчанию: `[]`).

## Пример использования

```yaml
- hosts: your_ubuntu_servers
  become: yes
  roles:
    - ubuntu-monitoring
  vars:
    # Включить установку Node Exporter
    # install_node_exporter: true
    # Отключить установку Zabbix Agent
    # install_zabbix_agent: false
    # Указать версию Zabbix Agent (например, "6.4" или "7.0")
    # zabbix_agent_version: "6.0"
    # Указать IP Zabbix Server
    # zabbix_server_ip: "your_zabbix_server_ip"
    # Указать IP Zabbix Server для активных проверок
    # zabbix_server_active_ip: "your_zabbix_server_active_ip"
    # Указать HostMetadataItem
    # zabbix_monitoring_client: "YourClientName"
    # Указать HostMetadata
    # zabbix_monitoring_metadata: ["Client:YourClientName", "OS:Linux", "DC:YourDC"]
```

## Лицензия

MIT

## Автор

Cline
