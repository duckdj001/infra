# Kubernetes Installation Role

This Ansible role installs Kubernetes 1.33 on Ubuntu 24.04 systems with containerd as the container runtime.

## Requirements

- Ubuntu 24.04 LTS
- Kernel version 5.15 or higher
- Ansible 2.9+
- Root or sudo access on target hosts

## Role Variables

### Default Variables (defaults/main.yml)

```yaml
# Kubernetes version and repository settings
k8s_tool_version: 1.33.0-1.1
k8s_package_repo: v1.33
k8s_ubuntu_version: 24.04

# Repository URLs
k8s_new_repo_url: https://pkgs.k8s.io/core:/stable:/v1.33/deb/
k8s_nexus_repo_url: https://nexus.metro-cc.ru/repository/k8s-v133-proxy
k8s_docker_download_url: https://download.docker.com

# Container runtime settings
k8s_containerd_root: /var/lib/containerd
k8s_containerd_socket: /run/containerd/containerd.sock
k8s_pause_image_version: "3.10"

# Registry settings
alter_registry_url: nexus.metro-cc.ru
containerd_config_default_write: true
```

## Dependencies

None

## Example Playbook

### Basic Installation (without cluster initialization)
```yaml
---
- hosts: k8s_nodes
  become: yes
  roles:
    - k8s.install
```

### Full Installation with Cluster Initialization and CNI
```yaml
---
- hosts: k8s_master
  become: yes
  vars:
    k8s_cluster_init: true
    k8s_install_cni: true
  roles:
    - k8s.install
```

### Installation with Custom Network Settings
```yaml
---
- hosts: k8s_master
  become: yes
  vars:
    k8s_cluster_init: true
    k8s_install_cni: true
    k8s_pod_network_cidr: "10.244.0.0/16"
    k8s_service_cidr: "10.96.0.0/12"
  roles:
    - k8s.install
```

### Cluster Recovery (if API server fails)
```yaml
---
- hosts: k8s_master
  become: yes
  vars:
    k8s_cluster_recovery: true
  roles:
    - k8s.install
```

## Example Inventory

```yaml
all:
  vars:
    ansible_ssh_common_args: "-o StrictHostKeyChecking=no"
  children:
    k8s_master:
      hosts:
        k8s-master-01:
          ansible_host: 10.207.141.131
        k8s-master-02:
          ansible_host: 10.207.141.132
        k8s-master-03:
          ansible_host: 10.207.141.133
```

## What This Role Does

1. **Prerequisites Check**: Validates Ubuntu 24.04 and minimum kernel version
2. **Repository Setup**: Configures Docker and Kubernetes v1.33 repositories via Nexus proxy
3. **Package Installation**: Installs containerd, kubectl, kubeadm, and kubelet
4. **System Configuration**: 
   - Disables swap
   - Configures kernel modules (overlay, br_netfilter)
   - Sets required sysctl parameters
5. **Container Runtime**: Configures containerd with registry mirrors and pause image

## Nexus Integration

This role is designed to work with Nexus Repository Manager as a proxy for:
- Docker Hub registry
- Kubernetes package repositories
- Container image registries

The role expects the following Nexus repositories to be configured:
- `k8s-v133-proxy`: Proxy for Kubernetes 1.33 packages
- `mirroryandexru-apt-proxy`: General APT package proxy

## Cluster Access

### Automatic Cluster Initialization
When you run the role with `k8s_cluster_init: true`, the role will:

1. **Initialize the cluster** on the first master node
2. **Join additional masters** to create a highly available control plane
3. **Download kubeconfig** to your local machine as `./kubeconfig-<hostname>`

### Accessing Your Cluster

After successful cluster initialization, you can access your cluster using:

```bash
# Copy the downloaded kubeconfig
cp ./kubeconfig-<first-master-hostname> ~/.kube/config

# Or set KUBECONFIG environment variable
export KUBECONFIG=./kubeconfig-<first-master-hostname>

# Test cluster access
kubectl get nodes
kubectl cluster-info
```

### Manual Post-Installation (if k8s_cluster_init: false)

If you didn't use automatic cluster initialization, you can manually initialize:

```bash
# On master node
sudo kubeadm init --pod-network-cidr=10.244.0.0/16

# Configure kubectl for root user (done automatically by role)
mkdir -p $HOME/.kube
sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
sudo chown $(id -u):$(id -g) $HOME/.kube/config

# Download kubeconfig to your local machine
scp root@<master-ip>:/etc/kubernetes/admin.conf ~/.kube/config

# Join worker nodes (get command from kubeadm init output)
sudo kubeadm join <master-ip>:6443 --token <token> --discovery-token-ca-cert-hash <hash>
```

### Kubeconfig Locations

- **On master nodes**: `/etc/kubernetes/admin.conf` and `/root/.kube/config`
- **Downloaded locally**: `./kubeconfig-<hostname>` (when using `k8s_cluster_init: true`)

## Troubleshooting

### Common Issues

1. **Repository Access**: Ensure Nexus proxy repositories are properly configured
2. **GPG Key Issues**: Verify GPG keys are properly imported for Ubuntu 24.04
3. **Network Connectivity**: Check firewall rules for Kubernetes ports (6443, 10250, etc.)

### Verification Commands

```bash
# Check Kubernetes version
kubectl version --client

# Verify containerd
sudo systemctl status containerd

# Check repository configuration
apt policy kubectl kubeadm kubelet
```

## Version History

- **v2.1**: Fixed kubelet configuration issue - added proper kubelet config.yaml creation
- **v2.0**: Updated for Kubernetes 1.33 and Ubuntu 24.04
- **v1.0**: Original version for Kubernetes 1.22 and Ubuntu 20.04/22.04

## Known Issues Fixed

### Kubelet Configuration Issue
**Problem**: `Path /var/lib/kubelet/config.yaml does not exist !`

**Solution**: The role now creates a proper kubelet configuration file with:
- Container runtime endpoint configuration
- Cluster DNS settings
- Authentication and authorization settings
- Resource management policies

This ensures kubelet starts correctly after installation.

## License

MIT

## Author Information

Metro IT Infrastructure Team
