<a name="1.4.0"></a>
## 1.4.0 (2021-11-10)




<a name="1.3.8"></a>
## 1.3.8 (2021-07-26)


#### Features

*   support deps versions ([a3ff0043](a3ff0043))



<a name="1.3.7"></a>
## 1.3.7 (2021-07-21)


#### Features

*   tag for dcs config ([2325ab21](2325ab21))



<a name="1.3.6"></a>
## 1.3.6 (2021-07-21)


#### Features

*   upgrade pip befor installing psycopg ([7b921077](7b921077))



<a name="1.3.5"></a>
## 1.3.5 (2021-04-20)


#### Bug Fixes

*   disable start and stop timeouts ([49771c80](49771c80))



<a name="1.3.4"></a>
## 1.3.4 (2021-03-02)


#### Features

*   add collections ([720fbf4e](720fbf4e))



<a name="1.3.1"></a>
## 1.3.1 (2020-07-27)


#### Bug Fixes

*   patroni_dcs_pg_recovery_conf ([294a45cb](294a45cb))



<a name="1.3.0"></a>
## 1.3.0 (2020-07-24)


#### Features

*   support ttl retry_timeout and loop_wait ([c1113aac](c1113aac))



<a name="1.2.2"></a>
## 1.2.2 (2020-07-21)


#### Bug Fixes

*   standby_cluster restore_command ([75e6b6f6](75e6b6f6))



<a name="1.2.1"></a>
## 1.2.1 (2020-07-21)


#### Bug Fixes

*   dont put recovery_conf if its empty ([e502b262](e502b262))



<a name="1.2.0"></a>
## 1.2.0 (2020-07-21)


#### Features

*   add recovery_conf ([e2d70240](e2d70240))



<a name="1.1.0"></a>
## 1.1.0 (2020-07-20)


#### Features

*   support pg_hba config ([67537d24](67537d24))



<a name="1.0.0"></a>
## 1.0.0 (2020-07-20)


#### Features

*   support dcs pg parameters ([896d18c9](896d18c9))



<a name="0.1.1"></a>
## 0.1.1 (2020-07-20)


#### Bug Fixes

*   make patroni health check more robust ([8915e699](8915e699))



<a name="0.1.0"></a>
## 0.1.0 (2020-07-20)


#### Features

*   support dcs changes and standby cluster ([989c4dae](989c4dae))
*   add netaddr ([491e2bea](491e2bea))
*   initial version ([e94bb8bb](e94bb8bb))



<a name="1.1.0"></a>
## 1.1.0 (2020-07-08)


#### Features

*   support truststore ([52bf0f2a](52bf0f2a))



<a name="1.0.5"></a>
## 1.0.5 (2020-07-08)


#### Bug Fixes

*   correct default for keycloak_frontend_url ([b96f520a](b96f520a))



<a name="1.0.4"></a>
## 1.0.4 (2020-07-08)


#### Bug Fixes

*   typo ([a4eee170](a4eee170))



<a name="1.0.3"></a>
## 1.0.3 (2020-07-08)


#### Bug Fixes

*   typo ([ccb761f7](ccb761f7))



<a name="1.0.2"></a>
## 1.0.2 (2020-07-08)


#### Features

*   make it use reverse proxy ([8197d661](8197d661))



<a name="1.0.1"></a>
## 1.0.1 (2020-07-08)


#### Features

*   add frontendUrl ([7135d994](7135d994))



<a name="1.0.0"></a>
## 1.0.0 (2020-07-08)


#### Features

*   first release ([a7e2edc5](a7e2edc5))



<a name="0.0.1"></a>
## 0.0.1 (2019-11-20)


#### Bug Fixes

*   Change default version, fix some errors in README ([992406fa](992406fa))



<a name="0.1.1"></a>
## 0.1.1 (2019-03-07)


#### Features

*   add molecule requirements feat: add Makefile ([b4f5ac73](b4f5ac73))



